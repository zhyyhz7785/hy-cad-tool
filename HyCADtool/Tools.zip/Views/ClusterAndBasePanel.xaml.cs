﻿using HyCADTool.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HyCADTool.Views
{
    /// <summary>
    /// ClusterAndBasePanel.xaml 的交互逻辑
    /// </summary>
    public partial class ClusterAndBasePanel : UserControl
    {
        public ClusterAndBasePanel()
        {
            InitializeComponent();
            this.DataContext = new ClusterAndBasePanelViewModel(); // ★ 正确绑定 ViewModel
        }
    }
}
