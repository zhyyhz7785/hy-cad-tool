# Layer Table Records
| 图层名称 | 颜色 | 线型 | 线宽 | 透明度 | 说明 |
|----------|------|------|------|--------|------|
| 0 | 7 | Continuous | ByLineWeightDefault | IsByLayer |  |
| 基础外轮廓线 | 7 | DASHED | ByLineWeightDefault | IsByLayer |  |
| dcelOuter | 1 | Continuous | ByLineWeightDefault | IsByLayer |  |
| dcelInter | 2 | Continuous | ByLineWeightDefault | IsByLayer |  |
| Defpoints | 7 | Continuous | ByLineWeightDefault | IsByLayer |  |
| BG&E - DIMENSIONS | 7 | Continuous | ByLineWeightDefault | IsByLayer |  |
| 00-HY-Hexagon | 5 | Continuous | ByLineWeightDefault | IsByLayer |  |
| Hy_Points | 4 | Continuous | ByLineWeightDefault | IsByLayer |  |
| 00-hy-group1 | 12 | Continuous | ByLineWeightDefault | IsByLayer |  |
| 00-hy-group2 | 14 | Continuous | ByLineWeightDefault | IsByLayer |  |
| 00-hy-group3 | 16 | Continuous | ByLineWeightDefault | IsByLayer |  |
| 00-hy-group4 | 18 | Continuous | ByLineWeightDefault | IsByLayer |  |
| 00-hy-group5 | 18 | Continuous | ByLineWeightDefault | IsByLayer |  |
| 00-hy-group6 | 18 | Continuous | ByLineWeightDefault | IsByLayer |  |
| 00-hy-group | 216 | Continuous | ByLineWeightDefault | IsByLayer |  |
| 00-HY-桩 | 3 | Continuous | ByLineWeightDefault | IsByLayer |  |
| 00-HY-Voronoi | 2 | Continuous | ByLineWeightDefault | IsByLayer |  |
| JICHUWAILUNKUO | 7 | Continuous | ByLineWeightDefault | IsByLayer |  |





| 图层名称          | 颜色 | 线型       | 线宽                | 透明度    | 说明 |
| ----------------- | ---- | ---------- | ------------------- | --------- | ---- |
| 0                 | 7    | Continuous | ByLineWeightDefault | IsByLayer |      |
| 基础外轮廓线      | 7    | DASHED     | ByLineWeightDefault | IsByLayer |      |
| dcelOuter         | 1    | Continuous | ByLineWeightDefault | IsByLayer |      |
| dcelInter         | 2    | Continuous | ByLineWeightDefault | IsByLayer |      |
| Defpoints         | 7    | Continuous | ByLineWeightDefault | IsByLayer |      |
| BG&E - DIMENSIONS | 7    | Continuous | ByLineWeightDefault | IsByLayer |      |
| 00-HY-Hexagon     | 5    | Continuous | ByLineWeightDefault | IsByLayer |      |
| Hy_Points         | 4    | Continuous | ByLineWeightDefault | IsByLayer |      |
| 00-hy-group1      | 12   | Continuous | ByLineWeightDefault | IsByLayer |      |
| 00-hy-group2      | 14   | Continuous | ByLineWeightDefault | IsByLayer |      |
| 00-hy-group3      | 16   | Continuous | ByLineWeightDefault | IsByLayer |      |
| 00-hy-group4      | 18   | Continuous | ByLineWeightDefault | IsByLayer |      |
| 00-hy-group5      | 18   | Continuous | ByLineWeightDefault | IsByLayer |      |
| 00-hy-group6      | 18   | Continuous | ByLineWeightDefault | IsByLayer |      |
| 00-hy-group       | 216  | Continuous | ByLineWeightDefault | IsByLayer |      |
| 00-HY-桩          | 3    | Continuous | ByLineWeightDefault | IsByLayer |      |
| 00-HY-Voronoi     | 2    | Continuous | ByLineWeightDefault | IsByLayer |      |
| JICHUWAILUNKUO    | 7    | Continuous | ByLineWeightDefault | IsByLayer |      |

```
using Microsoft.Win32; // 使用WPF中的SaveFileDialog
using System;
using System.IO;

namespace HyCADTool.Tools
{
    public static partial class EtGpt
    {
        // 指定默认目录路径（不含文件名）
        private static readonly string filePath = @"E:\BaiduSyncdisk\Code\CSharp\Rebuild1framwork\HyCADtoolGpt\HyCADtool";

        #region 主要方法
        // 获取保存文件路径，支持多种格式
        
        #endregion
    }
}
```

